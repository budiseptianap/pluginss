# FlutterFire - MOVED

The FlutterFire family of plugins has moved to the FirebaseExtended organization on GitHub. This makes it easier for us to collaborate with the Firebase team. We want to build the best integration we can!

Visit FlutterFire at its new home:
https://github.com/FirebaseExtended/flutterfire