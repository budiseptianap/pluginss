# android_alarm_manager_example

Demonstrates how to use the android_alarm_manager plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
