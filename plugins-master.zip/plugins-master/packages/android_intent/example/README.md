# android_intent_example

Demonstrates how to use the android_intent plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
