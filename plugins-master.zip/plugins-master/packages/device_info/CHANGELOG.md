## 0.4.1+2

* Remove AndroidX warning.

## 0.4.1+1

* Include lifecycle dependency as a compileOnly one on Android to resolve
  potential version conflicts with other transitive libraries.

## 0.4.1

* Support the v2 Android embedding.
* Update to AndroidX.
* Migrate to using the new e2e test binding.
* Add a e2e test.


## 0.4.0+4

* Define clang module for iOS.

## 0.4.0+3

* Update and migrate iOS example project.

## 0.4.0+2

* Bump minimum Flutter version to 1.5.0.
* Add missing template type parameter to `invokeMethod` calls.
* Replace invokeMethod with invokeMapMethod wherever necessary.

## 0.4.0+1

* Log a more detailed warning at build time about the previous AndroidX
  migration.

## 0.4.0

* **Breaking change**. Migrate from the deprecated original Android Support
  Library to AndroidX. This shouldn't result in any functional changes, but it
  requires any Android apps using this plugin to [also
  migrate](https://developer.android.com/jetpack/androidx/migrate) if they're
  using the original support library.

## 0.3.0

* Added ability to get Android ID for Android devices

## 0.2.1

* Updated Gradle tooling to match Android Studio 3.1.2.

## 0.2.0

* **Breaking change**. Set SDK constraints to match the Flutter beta release.

## 0.1.2

* Fixed Dart 2 type errors.

## 0.1.1

* Simplified and upgraded Android project template to Android SDK 27.
* Updated package description.

## 0.1.0

* **Breaking change**. Upgraded to Gradle 4.1 and Android Studio Gradle plugin
  3.0.1. Older Flutter projects need to upgrade their Gradle setup as well in
  order to use this version of the plugin. Instructions can be found
  [here](https://github.com/flutter/flutter/wiki/Updating-Flutter-projects-to-Gradle-4.1-and-Android-Studio-Gradle-plugin-3.0.1).

## 0.0.5

* Added FLT prefix to iOS types

## 0.0.4

* Fixed Java/Dart communication error with empty lists

## 0.0.3

* Added support for utsname

## 0.0.2

* Fixed broken type comparison
* Added "isPhysicalDevice" field, detecting emulators/simulators

## 0.0.1

* Implements platform-specific device/OS properties
