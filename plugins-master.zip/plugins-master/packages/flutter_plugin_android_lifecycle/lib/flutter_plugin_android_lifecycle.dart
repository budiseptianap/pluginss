// The flutter_plugin_android_lifecycle plugin only provides a Java API
// for use by Android plugins. This plugin has no Dart code.
